
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'nkatha',
  applicationName: 'serverless-todo-app-1',
  appUid: 'p3mvV3PHPrgwx0XtcC',
  orgUid: '9d498dfd-6281-43b1-a2f8-30754387c182',
  deploymentUid: '632d46bc-24df-4fc7-8238-7b342144af4d',
  serviceName: 'serverless-todo-app-1',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-1-dev-Auth', timeout: 6 };

try {
  const userHandler = require('./src/lambda/auth/auth0Authorizer.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}